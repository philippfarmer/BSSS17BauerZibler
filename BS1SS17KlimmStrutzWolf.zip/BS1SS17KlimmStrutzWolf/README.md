﻿# BS1-Praktikum
- Alex Strutz *[@astrutz](https://github.com/astrutz)*
- Torben Wolf *[@Tobiland](https://github.com/tobiland)*
- Marvin Klimm *[@marvinworks](https://github.com/marvinworks)*

Verantwortlicher Dozent: Matthias Böhmer *[@matboehmer](https://github.com/matboehmer)*

Aufgabenstellung im *[Wiki](https://wiki.moxd.io/display/BVSSS17/Praktikum)*
